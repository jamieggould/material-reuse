# Material Reuse Group — static website

A standalone copy of www.material-reuse.co.uk that no longer needs WordPress.
Every page, image, stylesheet, script and font from the live site is included and
all links are root-relative, so the folder works at the root of any domain.

## Pages

/ (home), /services/, /pre-project-planning/, /waste-reduction-solutions-and-material-reuse/,
/inventory/, /about-us/, /blogs/, /contact-us/, /early-access/, /privacy-policy/,
the two blog posts, /category/advice/, /category/guides/, /author/createteam/ and /home/.

## Deploying on Render

1. Put this folder in a Git repository (GitHub/GitLab) and push it.
2. In Render: New → Static Site → connect the repo.
   - Build command: leave empty
   - Publish directory: `.`
   (`render.yaml` in this folder already contains these settings if you use a Blueprint.)
3. Once deployed, add the custom domain `www.material-reuse.co.uk` in the Render
   service settings and update DNS as Render instructs.

## Forms (contact, early-access, privacy request)

The forms keep their original look and multi-step flow but are sent through
Web3Forms instead of Gravity Forms:

1. Go to https://web3forms.com, enter `kallie@material-reuse.co.uk`, and copy the
   access key that arrives by email.
2. Open `mrg-static/site-config.js` and paste it into `WEB3FORMS_ACCESS_KEY`.
3. Redeploy. Every submission is emailed to that address with all the answers.

Until the key is set, submitting a form opens the visitor's email app with the
answers pre-filled and addressed to kallie@material-reuse.co.uk.

## Fonts

Headings use an Adobe Fonts (Typekit) kit that is licensed to the
material-reuse.co.uk domain. They display correctly once the site is served
from that domain. If you preview on a temporary `*.onrender.com` address, add that
address to the kit's allowed domains in Adobe Fonts, or the browser will show a
fallback font until the real domain is connected.

## What changed from the WordPress version

- WordPress-only plumbing removed: REST/oEmbed/RSS links, emoji loader, admin
  heartbeat, Gravity Forms runtime and reCAPTCHA, partial-entries tracking.
- Site search is hidden (a static site has no search backend).
- Everything else is unchanged: cookie banner, FAQ toggles, carousels, video
  lightbox, Airtable inventory embed, Book-a-Call links, analytics.
- Static-site additions live in `mrg-static/` (config, form handler, a few CSS rules).
