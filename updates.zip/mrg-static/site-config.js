// Material Reuse Group static site configuration
window.MRG_CONFIG = {
  // Web3Forms: get a free access key for kallie@material-reuse.co.uk at
  // https://web3forms.com and paste it below. Until it is set, forms fall back
  // to opening the visitor's email client addressed to FALLBACK_EMAIL.
  FORM_ENDPOINT: "https://api.web3forms.com/submit",
  WEB3FORMS_ACCESS_KEY: "",
  SUBJECT: "New enquiry from material-reuse.co.uk",
  FALLBACK_EMAIL: "kallie@material-reuse.co.uk",
  SUCCESS_MESSAGE: "Thanks for contacting us! We will get in touch with you shortly."
};
